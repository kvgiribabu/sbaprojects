var express = require('express');
var routes = express.Router();
var config = require('./../config/configuration.js');
var mongoose = require('mongoose');
var parentTaskModel = require('./../models/parentTaskModel.js');
var taskModel = require('./../models/taskModel.js');
var mongodb = require('mongodb');


routes.post('/addtaskdetails',function(req,res){
  /* Inserting task details in respective tables */
  	var resultData = null;
  	var taskdetails = req.body;
  	var parentTask = new parentTaskModel({ 
	  	parentTask:taskdetails.parentTask
	});
  	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
 		db.collection("taskParent").find({parentTask:taskdetails.parentTask}).toArray(function(err, results) {
 			resultData = results;
	    	if (err) throw err;
		    else if(!resultData.length){
		    	db.collection("taskParent").insertOne(parentTask, function (err, result) {
			        if (err) {
			          	res.status(500).send('Internal Server Error');
			          	throw err;
			        }
			        else{
			        	insertTaskDetails(parentTask._id,'new');
			        }
		      	});
		    }
		    else{
		    	insertTaskDetails(resultData[0]._id,'existing');
		    }
		});
		function insertTaskDetails(id,status){
			var tasksList = new taskModel({
				task: taskdetails.task,
				Start_Date: taskdetails.startdate,
				End_Date: taskdetails.enddate,
				Priority: taskdetails.priority,
				Parent_ID : id
			});
			db.collection("tasks").insertOne(tasksList, function (err, result) {
				if(err){
					if(status == 'new'){
						db.collection("taskParent").deleteOne({_id:id}, function (err, result1) {
					        if (err) {
					            console.log("error query");
					        } else {
					            console.log(result1);
					        }
					    });
					}
					console.log("task not inserted successfully");
					res.status(500).send('Internal Server Error');
					throw err;
				}
				else{
					console.log("task inserted successfully");
					res.status(200).send('Task Added Successfully.');
				}
			})
			db.close();
		}
	});
})




routes.get('/getTasksList',function(req,res){
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
		db.collection('tasks').aggregate([
		    { $lookup:
		       {
		         from: 'taskParent',
		         localField: 'Parent_ID',
		         foreignField: '_id',
		         as: 'list'
		       }
		     }
		    ])
		.toArray(function(err, result) {
		    if (err) {
		    	console.log("task details not fetch successfully");
		    	res.status(500).send('Internal Server Error');
		    }
		    else{
		    	console.log("task details fetch successfully");
				res.status(200).json(JSON.stringify(result));
			}
		 });
		db.close();
	});
});
routes.post('/deleteTask',function(req,res){
	var childID = req.body.childID;
	var parentID = req.body.parentID;
		console.log(childID);
		console.log(parentID);
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
     	db.collection("tasks").find({Parent_ID:parentID}).toArray(function(err, results) {
     		if(results.length==1){
				db.collection("taskParent").deleteOne({_id: new mongodb.ObjectID(parentID)},function(err,numberRemoved){
		            if(err){
		            	console.log('Task Not Deleted Successfully.');
		            	res.status(500).send('Internal Server Error');
		            }
		        })
     		}
     			db.collection("tasks").deleteOne({_id: new mongodb.ObjectID(childID)},function(err,numberRemoved){
		            if(err){
		            	console.log('Task Not Deleted Successfully.');
		            	res.status(500).send('Internal Server Error');
		            }
		            else{
		            	console.log(numberRemoved);
		            	console.log('Task Deleted Successfully.');
		            	res.status(200).send('Task Deleted Successfully.');
		            }
		        })
		})
	});
});
routes.post('/getTaskID',function(req,res){
	var childID = req.body.childID;
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
		db.collection('tasks').aggregate([
			 { "$match": {_id: new mongodb.ObjectID(childID) }},
		    { $lookup:
		       {
		         from: 'taskParent',
		         localField: 'Parent_ID',
		         foreignField: '_id',
		         as: 'list'
		       }
		     }
		    ])
		.toArray(function(err, result) {
		    if (err) {
		    	console.log("task details not fetch successfully");
		    	res.status(500).send('Internal Server Error');
		    }
		    else{
		    	console.log("task details fetch successfully");
				res.status(200).json(JSON.stringify(result));
			}
		 });
		db.close();
	});
});
routes.post('/editTask',function(req,res){
	var taskDetails = req.body;
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
 		db.collection("taskParent").find({parentTask:taskDetails.parentTask}).toArray(function(err, results) {
 			resultData = results;
 			if(results.length==1){
 				db.collection("tasks").updateOne({_id: new mongodb.ObjectID(taskDetails.id)},
 				{ $set: {
					task: taskDetails.task,
					Start_Date: taskDetails.startdate,
					End_Date: taskDetails.enddate,
					Priority: taskDetails.range,
					Parent_ID:resultData[0]._id
 				}}, 
 				function(err, result) {
			      if (err)
			      {
			        console.log(err);
			        res.status(500).send('Internal Server Error');

			      }
			      else{
			        console.log(result);
			        console.log("updated successfully");
			        res.status(200).send('Task Updated Successfully.');
			      }
			    });
 			}
 			else{
 				var parentTask = new parentTaskModel({ 
				  	parentTask:taskDetails.parentTask
				});
 				db.collection("taskParent").insertOne(parentTask, function (err, result) {
			        if (err) {
			          	//res.status(500).send('Internal Server Error');
			          	console.log(err);
			          	console.log("error");
			        }
			        else{
		 				db.collection("tasks").updateOne({_id: new mongodb.ObjectID(taskDetails.id)},
		 				{ $set: {
							task: taskDetails.task,
							Start_Date: taskDetails.startdate,
							End_Date: taskDetails.enddate,
							Priority: taskDetails.range,
							Parent_ID:parentTask._id
		 				}}, 
		 				function(err, result) {
					      if (err)
					      {
					        console.log(err);
					        res.status(500).send('Internal Server Error');
					      }
					      else{
					        console.log(result);
					        console.log("updated successfully");
					        res.status(200).send('Task Updated Successfully.');

					      }
					    });
			        }
		      	});

 			}
 		})
 	})		
})
routes.post('/getSearchedTasks',function(req,res){
	var taskDetails = req.body;
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
		db.collection("taskParent").find({parentTask:taskDetails.parentTask}).toArray(function(err, results) {
 			resultData = results;
 			var searchObject = {};
 			var query = [],
 			datestring = '',
 			dateArray = [];
 			for(var key in taskDetails){
 				if(key == 'task'){
 					query.push({'task':taskDetails['task']});
 				}
 				else if(key == 'startdate'){
 					datestring += 'start';
 				}else if(key == 'enddate'){
 					datestring += 'end';
 				}
 			}
 			if(resultData.length>0){
 				query.push({Parent_ID:new mongodb.ObjectID(resultData[0]._id)});
 			}
 			if(taskDetails['rangeFrom'] && taskDetails['rangeTo']){
 				var range = {'Priority':{ $gte :  taskDetails['rangeFrom'], $lte : taskDetails['rangeTo']}};
 				query.push(range);
 			}else if(taskDetails['rangeFrom']){
 				var range = { "Priority" :  taskDetails['rangeFrom']};
 				query.push(range);
 			}else if(taskDetails['rangeTo']){
 				var range = { "Priority" :  taskDetails['rangeTo']};
 				query.push(range);
 			}
 			if(datestring ==='startend' || datestring === 'endstart'){
 				query.push({$and : [{'Start_Date' : { $gte : taskDetails['startdate'] }},{'End_Date' : { $lte : taskDetails['enddate'] }}]});
 			}else if(datestring=='start'){
 				query.push({'Start_Date' : { $gte : taskDetails['startdate'] }});

 			}else if(datestring=='end'){
 				query.push({'End_Date' : { $lte : taskDetails['enddate']}});
 			}
 			var finalQuery = {$or: query};
				db.collection('tasks').aggregate([
					 { "$match": finalQuery},
				    { $lookup:
				       {
				         from: 'taskParent',
				         localField: 'Parent_ID',
				         foreignField: '_id',
				         as: 'list'
				       }
				     }
			    ])
			.toArray(function(err, result) {
			    if (err) {
			    	console.log("task details not fetch successfully");
			    	res.status(500).send('Internal Server Error');
			    }
			    else{
			    	console.log("task details fetch successfully");
					res.status(200).json(JSON.stringify(result));
				}
			 });
 		});
	})
})


module.exports = routes;