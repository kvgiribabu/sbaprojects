var express = require('express');
var routes = express.Router();
var config = require('./../config/configuration.js');
var mongoose = require('mongoose');
var userModel = require('./../models/userModel.js');
var projectModel = require('./../models/projectModel.js');
var mongodb = require('mongodb');

/* User Related APIs Start*/
/* 1.Insert User Data */
routes.post('/insertUser',function(req,res){
  	var resultData = null;
  	var userPayload = req.body;
  	var userList = new userModel({
		firstName: userPayload.firstName,
		lastName: userPayload.lastName,
		empID: userPayload.empID,
	});
	console.log("user userPayload");
	console.log(userList);
  	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
	    db.collection("user").find({empID:userPayload.empID}).toArray(function(err, results) {
	    	console.log("user results");
	    	console.log(results);
	    	resultData = results;
	    	if (err) throw err;
	    	else if(!resultData.length){
				db.collection("user").insertOne(userList, function (err, result) {
					if(err){
						console.log("User data not inserted successfully");
						res.status(500).send({"msg":'Internal Server Error.Please try again after sometime.'});
						throw err;
					}
					else{
						console.log("User data inserted successfully");
						res.status(200).send({"msg":'User data inserted Successfully.'});
					}
				})
			}
			else{
     			console.log("User is already exist");
				res.status(200).send({"msg":'User already exist.'});
     		}
     	})
     });
})
/* 2.Get All The User Data */
routes.get('/getUsers',function(req,res){
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
	    db.collection("user").find().toArray(function(err, results) {
	    	if(err){
				console.log("No data found");
				res.status(500).send({"msg":'Internal Server Error.Please try again after sometime.'});
				throw err;
			}
			else{
				//console.log(results);
				console.log("User data fetched successfully");
				res.status(200).json(results);
			}

	    });
	});
});


/* 3.Delete User Data */

routes.post('/deleteUser',function(req,res){
	var userPayload = req.body;
	console.log(userPayload)
	console.log(userPayload._id);
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	db.collection("user").deleteOne({_id: new mongodb.ObjectID(userPayload._id)},function(err,numberRemoved){
     		if(err){
				console.log("User data is not deleted");
				res.status(500).send({"msg":'Internal Server Error.Please try again after sometime.'});
				throw err;
			}
			else{
				console.log(numberRemoved);

				console.log("User data is deleted successfully");
				res.status(200).json(numberRemoved);
			}
  		});
	});
});

/* 4.Update User Data */
routes.post('/updateUser',function(req,res){
	var userPayload = req.body;
	console.log(userPayload)
	console.log(userPayload._id);
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
 		db.collection("user").find({empID:userPayload.empID}).toArray(function(err, results) {
 			resultData = results;
 			console.log(resultData.length);
 			console.log("length")
 			if(resultData.length>0){
 			console.log("User already exists.");
			res.status(200).send({"msg":'User already exists with EmpId: '+userPayload.empID});
 			}else{
				db.collection("user").updateOne({_id: new mongodb.ObjectID(userPayload._id)},
 				{ $set: {
					firstName: userPayload.firstName,
					lastName: userPayload.lastName,
					empID: userPayload.empID
 				}}, 
 				function(err, result) {
			      if (err)
			      {
			        console.log(err);
			        res.status(500).send('Internal Server Error');
			      }
			      else{
			        //console.log(result);
			        console.log("updated successfully");
			        res.status(200).send({"msg":'User Updated Successfully.'});
			      }
			    });
			}
 		})
 	})
});

/* 5.get searched User Data */

routes.post('/getSearchedUsers',function(req,res){
	var userPayload = req.body;
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
 		db.collection("user").find({$or:[{"firstName":userPayload.searchedValue},{"lastName":userPayload.searchedValue},{"empID":userPayload.searchedValue}]}).toArray(function(err, results) {
 			console.log("searched resultsfsdf")
 			console.log(results)
 			res.status(200).json(results);
 		});
 	});
});
/* User Related APIs End*/



/*Project  Related APIs Start*/

/* 1.Insert Project Data */

routes.post('/insertProjectData',function(req,res){
  	var resultData = null;
  	var projectPayload = req.body;
  	var projectList = new projectModel({
		projectName:projectPayload.projectName,
    	startDate:projectPayload.startDate,
		setDate:projectPayload.setDate,
		endDate:projectPayload.endDate,
		priority:projectPayload.priority,
		manager:projectPayload.manager
	});
	console.info("project Payload");
	console.info(projectList);
  	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
	    db.collection("project").find({projectName:projectPayload.projectName}).toArray(function(err, results) {
	    	resultData = results;
	    	if (err) throw err;
	    	else if(!resultData.length){
				db.collection("project").insertOne(projectList, function (err, result) {
					if(err){
						console.info("Project data is not inserted successfully");
						res.status(500).send({"msg":'Internal Server Error.Please try again after sometime.'});
						throw err;
					}
					else{
						console.info("Project  data is inserted successfully");
						res.status(200).send({"msg":'Project data is inserted Successfully.'});
					}
				})
			}
			else{
     			console.info("Project is already exist");
				res.status(200).send({"msg":'Project is already exist.'});
     		}
     	})
     });
})

/* 2.Get All Project Data */


routes.get('/getProjectDetails',function(req,res){
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
	    db.collection("project").find().toArray(function(err, results) {
	    	if(err){
				console.log("No data found");
				res.status(500).send({"msg":'Internal Server Error.Please try again after sometime.'});
				throw err;
			}
			else{
				console.log(results);
				console.log("Project data  fetched successfully");
				res.status(200).json(results);
			}

	    });
	});
});


/* 3.Update project Data*/

routes.post('/updateProject',function(req,res){
	var projectPayload = req.body;
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
 		db.collection("project").find({projectName:projectPayload.projectName}).toArray(function(err, results) {
 			resultData = results;
 			console.log(resultData.length);
 			if(results.length>0){
 				console.log("Project already exists.");
			    res.status(200).send({"msg":'Project already exists with project  name: '+projectPayload.project});
 			}else{
				db.collection("project").updateOne({_id: new mongodb.ObjectID(projectPayload._id)},
					{ $set: {
					projectName:projectPayload.projectName,
					startDate:projectPayload.startDate,
					setDate:projectPayload.setDate,
					endDate:projectPayload.endDate,
					priority:projectPayload.priority,
					manager:projectPayload.manager
					}}, 
					function(err, result) {
			      if (err)
			      {
			        console.log(err);
			        res.status(500).send({"msg":'Internal Server Error'});
			      }
			      else{
			        console.log(result);
			        console.log("updated successfully");
			        res.status(200).send({"msg":'Project Updated Successfully.'});
			      }
			    });
			}
 		})
 	})

	/*mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
			db.collection("project").updateOne({_id: new mongodb.ObjectID(projectPayload._id)},
			{ $set: {
			project:projectPayload.project,
			startDate:projectPayload.startDate,
			setDate:projectPayload.setDate,
			endDate:projectPayload.endDate,
			priority:projectPayload.priority,
			manager:projectPayload.manager
			}}, 
			function(err, result) {
	      if (err)
	      {
	        console.log(err);
	        res.status(500).send({"msg":'Internal Server Error'});
	      }
	      else{
	        console.log(result);
	        console.log("updated successfully");
	        res.status(200).send({"msg":'Project Updated Successfully.'});
	      }
	    });
 	})*/
});

/* 4.get searched Project Data */

routes.post('/getSearchedProject',function(req,res){
	var projectPayload = req.body;
	mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err,db){
     	if (err) throw err;
 		db.collection("project").find({projectName:projectPayload.searchedValue}).toArray(function(err, results) {
 			console.log("searched project");
 			console.log(results);
 			res.status(200).json(results);
 		});
 	});
});


/* Project Related APIs End*/
module.exports = routes;