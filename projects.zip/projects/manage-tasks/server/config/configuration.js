var config = {
	"PORT":5000,
	"mongooseDbUrl":"'mongodb://localhost:27017/tasksdb"
}
module.exports = config;