const parentTask = require('../models/parentTaskModel.js');
var mongoose = require('mongoose');
Schema = mongoose.Schema;
const taskSchema = new mongoose.Schema({
    task: String,
    Start_Date: String,
  	End_Date: String,
  	Priority:Number,
  	Parent_ID : { type: Schema.Types.ObjectId, ref: 'parentTask' }
});
module.exports = mongoose.model('tasks', taskSchema);