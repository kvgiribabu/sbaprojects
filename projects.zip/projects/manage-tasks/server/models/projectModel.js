var mongoose = require('mongoose');
Schema = mongoose.Schema;
const projectSchema = new mongoose.Schema({
    projectName: String,
    startDate: String,
	setDate:String,
	endDate: String,
	priority:Number,
	manager:String
  	
});
module.exports = mongoose.model('project', projectSchema);