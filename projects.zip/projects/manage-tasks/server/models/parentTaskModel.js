var mongoose = require('mongoose');
const parentTaskSchema = new mongoose.Schema({
  parentTask: {
    type: String,
    unique: true,
    index: true
  },
});
module.exports = mongoose.model('parentTask', parentTaskSchema);