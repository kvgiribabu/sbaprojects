var mongoose = require('mongoose');
Schema = mongoose.Schema;
const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
  	empID: String
  	
});
module.exports = mongoose.model('user', userSchema);