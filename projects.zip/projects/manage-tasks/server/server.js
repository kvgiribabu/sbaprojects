var config = require('./config/configuration.js');
var express = require('express');
var cors = require('cors');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
app.use(cors());
app.use(bodyParser.json());
mongoose.connect(config.mongooseDbUrl,{useNewUrlParser: true} , function(err){
   if (err) throw err;
   console.log('Successfully connected');
});

var api = require('./routes/api.js')
app.use('/api', api);
app.listen(config.PORT,function(){
	console.log("SERVER LISTINEING ON PORT "+config.PORT);
})