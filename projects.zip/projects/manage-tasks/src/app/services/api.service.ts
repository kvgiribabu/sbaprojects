import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {User} from "./../model/user.model";
import {Project} from "./../model/project.model";
import {Observable} from "rxjs/index";
import {ApiResponse} from "./../model/api.response";

@Injectable()
export class ApiService {

  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:5000/api/';


   createUser(user: User): Observable<ApiResponse> {
      console.log(user);
      console.log("create user details");
      return this.http.post<ApiResponse>(this.baseUrl+"insertUser", user);
  }

  getUsers() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+"getUsers");
  }

  deleteUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +"deleteUser" , user);
  }

  updateUser(user,id: number): Observable<ApiResponse> {
    user['_id'] = id
    return this.http.post<ApiResponse>(this.baseUrl+"updateUser",user);
  }

 getSearchedUsers(payload:any): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +"getSearchedUsers",payload);
  }

  /*updateUser(user: User): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(this.baseUrl + user.id, user);
  }*/


  createProject(project: Project): Observable<ApiResponse> {
      console.log(project);
      console.log("create project details");
      return this.http.post<ApiResponse>(this.baseUrl+"insertProjectData", project);
  }

  getProject() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+"getProjectDetails");
  }

  updateProject(project:Project,id: number): Observable<ApiResponse> {
    project['_id'] = id
    return this.http.post<ApiResponse>(this.baseUrl+"updateProject",project);
  }

  getSearchedProject(payload:any): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +"getSearchedProject",payload);
  }

}