export class Project {
	projectName: string;
	startDate: string;
	setDate:string;
	endDate: string;
	priority:number;
	manager:string
}