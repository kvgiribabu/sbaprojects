export class User {
	firstName: string;
	lastName: string;
	empID: string;
}