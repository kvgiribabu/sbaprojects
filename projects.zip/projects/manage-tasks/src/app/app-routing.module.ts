import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddprojectComponent } from './components/addproject/addproject.component';
import { AdduserComponent } from './components/adduser/adduser.component';
import { AddtaskComponent } from './components/addtask/addtask.component';
import { ViewtaskComponent } from './components/viewtask/viewtask.component';


const routes: Routes = [

  {
    path: 'addproject',
    component: AddprojectComponent
  },
  {
    path: 'addtask',
    component: AddtaskComponent
  },
  {
    path: 'adduser',
    component: AdduserComponent
  },
  {
    path: 'viewtask',
    component: ViewtaskComponent
  },
  { path: '',   redirectTo: '/addproject', pathMatch: 'full' },
  { path: '**', component: AddprojectComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
