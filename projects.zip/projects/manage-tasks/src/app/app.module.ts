import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {ReactiveFormsModule} from "@angular/forms";


import {ApiService} from "./services/api.service";
import { SortArrayNames } from './components/pipes/sortarraynames.pipe';
import { DatePipes } from './components/pipes/date.pipe';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { AddprojectComponent } from './components/addproject/addproject.component';
import { AdduserComponent } from './components/adduser/adduser.component';
import { AddtaskComponent } from './components/addtask/addtask.component';
import { ViewtaskComponent } from './components/viewtask/viewtask.component';


export function translateHttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavigationComponent,
    AddprojectComponent,
    AdduserComponent,
    AddtaskComponent,
    ViewtaskComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: translateHttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [ApiService,SortArrayNames,DatePipes],
  bootstrap: [AppComponent]
})
export class AppModule { }
