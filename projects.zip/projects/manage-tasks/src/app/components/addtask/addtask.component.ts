import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators,FormControl} from "@angular/forms";
import {Router} from "@angular/router";

import {ApiService} from "./../../services/api.service";

import { SortArrayNames } from './../pipes/sortarraynames.pipe';
import { DatePipes } from './../pipes/date.pipe';

@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {

  priorityValue:number = 0;
  dateError:string = "";
  users:any=[];
  projects:any=[];
  updateProjects:any=[];
  isLoading:boolean = true;
  task: FormGroup;
  update:boolean = true;
  buttonValue:string = "Add";
  message:string='';
  updatedId:number = 0;
  constructor(private formBuilder: FormBuilder,  private router: Router, private apiService: ApiService,private sortarraynames: SortArrayNames,private datePipes: DatePipes) { }
  addProject: FormGroup;
  ngOnInit() {
    this.buttonValue = "Add";
  	this.task = this.formBuilder.group({
  		projectName:[{value:'',disabled: true}],
      taskName:['', Validators.required]
      /*setDate:[''],
      startDate:[{value:'',disabled: true}],
      endDate:[{value:'',disabled: true}],
      priority:[0, Validators.required],
      manager:['', Validators.required]*/
    });
    this.apiService.getProject()
      .subscribe( data => {
        this.projects = data;
    });
  }
    searchProject(){
    	this.isLoading =false;
    	this.projects = [];
    	console.log("search projects");
  		this.apiService.getProject()
      		.subscribe( data => {
        	this.projects = data;
    	});
    }
  	closeModal(){
  		this.isLoading =true;
  	}
  	selectedProject(project){
  		this.task.get('projectName').setValue(project.projectName);
  		this.closeModal()
    }

    search(event){
    let payload = {
      "searchedValue":event.target.value
    };
    if(event.target.value){
      this.apiService.getSearchedProject(payload)
      .subscribe( data => {
        this.projects = data;
    });
    }else{
      this.searchProject();
    }
  }
}
