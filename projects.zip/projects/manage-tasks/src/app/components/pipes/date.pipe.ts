import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'datepipes'
})
export class DatePipes implements PipeTransform {
  transform(){}
  getTodayDate(): any {
    var myDate=new Date();
	var todayDate = myDate.getFullYear() + '-' + ("0" + (myDate.getMonth() + 1)).slice(-2) + '-' +  myDate.getDate();
	return todayDate;   
  }
  getTomorrowDate(): any {
    var myDate=new Date();
	myDate.setDate(myDate.getDate()+1);
	var tomorrowDate = myDate.getFullYear()+'-'+("0" + (myDate.getMonth() + 1)).slice(-2)+'-'+ myDate.getDate();
	return tomorrowDate;
  }

  compareDates(startDate:string,endDate:string):boolean{
  		var d1 = new Date(startDate);
        var d2 = new Date(endDate);
        return d2.getTime()>d1.getTime();
  }
}