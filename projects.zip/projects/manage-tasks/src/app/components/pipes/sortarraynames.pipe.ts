import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'sortarray'
})
export class SortArrayNames implements PipeTransform {
  transform(){}
  nameFilter(array: any, name:string, args?: any): any {
    array.sort((a, b) => a[name].localeCompare(b[name]));
	return array;   
  }
  idFilter(array: any, id:string , args?: any): any {
    array.sort((a, b) => a[id].localeCompare(b[id]));
	return array  
  }
}
