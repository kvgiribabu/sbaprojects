import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ApiService} from "./../../services/api.service";
import {User} from "./../../model/user.model";
import { SortArrayNames } from './../pipes/sortarraynames.pipe';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  message:string='';
  users:any=[];
  buttonValue:string = "Add";
  update:boolean = false;
  updatedId:number = 0;
  addForm: FormGroup;
  constructor(private formBuilder: FormBuilder,  private router: Router, private apiService: ApiService,private sortarraynames: SortArrayNames) { }
  ngOnInit() {
  this.buttonValue = "Add";
    this.addForm = this.formBuilder.group({
      firstName:['', Validators.required],
      lastName:['', Validators.required],
      empID:['', Validators.required]    
    });
    this.apiService.getUsers()
      .subscribe( data => {
        this.users = data;
    });
  }
  onSubmit() {
  console.log(this.addForm.value);
  if(this.update){
    this.apiService.createUser(this.addForm.value)
     .subscribe( data => {
        console.log("data");
        console.log(data);
        this.message = data['msg'];
      });
  }else{
    this.apiService.updateUser(this.addForm.value,this.updatedId)
     .subscribe( data => {
        console.log("data");
        console.log(data);
        this.message = data['msg'];
          this.ngOnInit();
        });
      
  }
  }
  deleteUser(user: User): void {
    this.apiService.deleteUser(user)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };
  editUser(user: User): void {
     this.addForm = this.formBuilder.group({
      firstName:[user.firstName, Validators.required],
      lastName:[user.lastName, Validators.required],
      empID:[user.empID, Validators.required]    
    });
    this.updatedId = user['_id'];
    this.buttonValue = "Update";
  };
  search(event){
    console.log(event.target.value);
    let payload = {
      "searchedValue":event.target.value
    }
    if(event.target.value){
      this.apiService.getSearchedUsers(payload)
      .subscribe( data => {
        this.users = data;
        console.log(data);
        console.log(this.users.length);
    });
    }else{
      this.ngOnInit();
    }
      }
  sortArrayFirstNameFun(){
      this.users=this.sortarraynames.nameFilter(this.users,'firstName');
  }
  sortArrayLastNameFun(){
      this.users=this.sortarraynames.nameFilter(this.users,'lastName');
  }
  sortArrayIDFun(){
      this.users=this.sortarraynames.idFilter(this.users,'empID');
  }
}
