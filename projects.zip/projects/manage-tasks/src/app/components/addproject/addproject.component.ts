import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators,FormControl} from "@angular/forms";
import {Router} from "@angular/router";

import {ApiService} from "./../../services/api.service";
import {User} from "./../../model/user.model";
import {Project} from "./../../model/project.model";
import { SortArrayNames } from './../pipes/sortarraynames.pipe';
import { DatePipes } from './../pipes/date.pipe';

@Component({
  selector: 'app-addproject',
  templateUrl: './addproject.component.html',
  styleUrls: ['./addproject.component.css']
})
export class AddprojectComponent implements OnInit {
  priorityValue:number = 0;
  dateError:string = "";
  users:any=[];
  projects:any=[];
  updateProjects:any=[];
  isLoading:boolean = true;
  addProject: FormGroup;
  update:boolean = true;
  buttonValue:string = "Add";
  message:string='';
  updatedId:number = 0;
  constructor(private formBuilder: FormBuilder,  private router: Router, private apiService: ApiService,private sortarraynames: SortArrayNames,private datePipes: DatePipes) { }
  ngOnInit() {
    this.buttonValue = "Add";
  	this.addProject = this.formBuilder.group({
      projectName:['', Validators.required],
      setDate:[''],
      startDate:[{value:'',disabled: true}],
      endDate:[{value:'',disabled: true}],
      priority:[0, Validators.required],
      manager:['', Validators.required]
    });
    this.apiService.getProject()
      .subscribe( data => {
        this.projects = data;
    });
  }
  handleChange(value: boolean) {
    const startDate = this.addProject.get('startDate');
    const endDate = this.addProject.get('endDate');
    if (value) {
      if(this.update){
        this.addProject.get('startDate').setValue(this.datePipes.getTodayDate());
        this.addProject.get('endDate').setValue(this.datePipes.getTomorrowDate());
      }else{
        this.addProject.get('startDate').setValue(this.updateProjects.startDate);
        this.addProject.get('endDate').setValue(this.updateProjects.endDate);
      }
    startDate.enable();
    endDate.enable();
    } 
    else {
      this.addProject.get('startDate').setValue('');
      this.addProject.get('endDate').setValue('');
      startDate.disable();
      endDate.disable();
    }
  }
  setPriority(value){
  	this.priorityValue = value;
  }
  searchManager(){
    this.isLoading =false;
    this.users = [];
  	this.apiService.getUsers()
      .subscribe( data => {
        this.users = data;
    });
  }
  closeModal(){
  	this.isLoading =true;
  }
  selectedUser(user){
  	this.addProject.get('manager').setValue(user.firstName+' '+user.lastName);
  	this.closeModal()
  }
  search(event){
    let payload = {
      "searchedValue":event.target.value
    };
    if(event.target.value){
      this.apiService.getSearchedUsers(payload)
      .subscribe( data => {
        this.users = data;
    });
    }else{
      this.searchManager();
    }
  }
  onSubmit() {
    var compareDates = this.datePipes.compareDates(this.addProject.get('startDate').value,this.addProject.get('endDate').value)
    	if(!compareDates){
    		this.dateError = "End date should be greater than start date";
    	}else{
    	 	this.dateError = "";
    	}
    if(this.update){
      this.apiService.createProject(this.addProject.value).subscribe( data => {
          console.log("data");
          console.log(data);
          this.message = data['msg'];
        });

    }else{
      console.log("update user");
      this.apiService.updateProject(this.addProject.value,this.updatedId)
       .subscribe( data => {
       this.buttonValue = "Add";
          this.message = data['msg'];
            this.ngOnInit();
          });
    }
  }
  editProject(project: Project): void {
      this.updateProjects = project;
      this.update = false;
      const startDate = this.addProject.get('startDate');
      const endDate = this.addProject.get('endDate');
      this.priorityValue = project.priority;
      this.addProject = this.formBuilder.group({
      projectName:[project.projectName, Validators.required],
      setDate:[project.setDate],
      startDate:[project.startDate],
      endDate:[project.endDate],
      priority:[project.priority, Validators.required],
      manager:[project.manager, Validators.required],  
    });
    if(project.setDate){
      startDate.enable();
      endDate.enable();
    }
    this.updatedId = project['_id'];
    this.buttonValue = "Update";
  };
}